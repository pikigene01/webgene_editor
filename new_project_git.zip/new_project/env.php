<?php

/* webgene editor variables

================
DB

USERNAME

PASSWORD

================ */

$user_host = "localhost";
$user_name = "root";
$user_pass = "";
$db = "web_gene";