# Backers

Support Swiper development by [pledging on Open Collective](http://opencollective.com/swiper)!

### \$500 Platinum Sponsor

[Currently vacant. It could be you!](https://opencollective.com/swiper/contribute/platinum-sponsor-24468/checkout)

---

### \$250 Gold Sponsor

[Currently vacant. It could be you!](https://opencollective.com/swiper/contribute/gold-sponsor-24466/checkout)

---

### \$100 Silver Sponsor

[Currently vacant. It could be you!](https://opencollective.com/swiper/contribute/silver-sponsor-24464/checkout)

---

### \$50+ Sponsor

[Currently vacant. It could be you!](https://opencollective.com/swiper/contribute/sponsor-24467/checkout)

---

### \$25+ Top Supporter

[Currently vacant. It could be you!](https://opencollective.com/swiper/contribute/top-supporter-24465/checkout)

---

### \$10+ Supporter

[Currently vacant. It could be you!](https://opencollective.com/swiper/contribute/supporter-23766/checkout)

---

### \$5+ Thank You

[Currently vacant. It could be you!](https://opencollective.com/swiper/contribute/thank-you-23765/checkout)
