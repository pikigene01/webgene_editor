<script src="js/app.js"></script>
        
        <script src="js/vidgene.min.js"></script>
        <script src="js/jquery.form.js"></script>
        <script src="js/emojionearea.min.js"></script>
        <script src="js/vidgene-ui.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/vidgene.timeago.js"></script>

        <script src="js/swiper-bundle.min.js"></script>
        <script src="js/scrollreveal.min.js"></script>
        <script src="js/file-upload/js/vendor/jquery.ui.widget.js"></script>
<script src="js/file-upload/js/jquery.iframe-transport.js"></script>
<script src="js/file-upload/js/jquery.fileupload.js"></script>
<!--<script src="croppie.js"></script>-->