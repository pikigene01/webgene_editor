<?php
session_start();
include_once "connection.php";

if(isset($_POST['secrete_code'])){

    $secrete_code =  $con->real_escape_string($_POST['secrete_code']);
    
     $sql = $con->query("SELECT * FROM webgene_auth WHERE id='1'");
       if ($sql->num_rows == 0){
       $ePassword = password_hash($secrete_code, PASSWORD_BCRYPT);
       $con->query("INSERT INTO webgene_auth (secrete_code,created_at) VALUES ('$ePassword',NOW() )");
       exit('success');
       }else{
        
           $data = $sql->fetch_assoc();
           $passwordHash = $data['secrete_code'];
           
           if (password_verify($secrete_code, $passwordHash)){
            
           $_SESSION['editing'] = 1;
           $_SESSION['name'] = $data['id'];
          
           
           exit('success');
           }else
       exit('incorrect');
   
          
       }
       
   }
