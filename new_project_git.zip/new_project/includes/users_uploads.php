<?php
include("connection.php");
session_start();

if(isset($_GET['user_uploads'])){



    $posts = $con->query("SELECT * FROM users_uploads WHERE user_id = '1' ORDER BY upload_id DESC ");
    ?>
    <div class="grid-img">
    <?php
if($posts->num_rows > 0){
    
while($post = mysqli_fetch_assoc($posts)){
    $post_id = $post['upload_id'];
 $post_link = $post['upload_link'];
 $post_type = $post['upload_type'];
 $post_date = $post['created_at'];
 $post_folder = $post['upload_folder'];
 $post_type = $post['upload_type'];
 $post_size = $post['upload_size'];
$post_type = substr($post_type,0,5);
 if($post_type === 'video'){
?>
         
<?php

 }else{
?>
             
            
        <div class="center-block">
        <img ondblclick="delete_upload('<?php echo $post_id ?>', '<?php echo $post_folder ?>')" src="<?php echo $post_link ?>" style="width:40px;height:40px;bottom:0px;" class="user_upload_img">

 </div>
    
 
<?php
 }

}

}else{
    exit('No Published Posts');
}
}

?>

</div>