<?php

$con = new mysqli('localhost', 'root', '', 'web_gene');

if($con){
   $msg = 'connected';
}else{
    $msg = 'failed';
}

//exit(json_encode(array($msg)));