<?php
session_start();
include('connection.php');
if(isset($_SESSION['name'])){
if(isset($_POST['change_site'])){
    
    $html_id = $con->real_escape_string($_POST['html_tag_id']);
    $html_text = $con->real_escape_string($_POST['html_text']);
    $type = $con->real_escape_string($_POST['type']);
    $user_id = '1';
    $sql = $con->query("SELECT * FROM html_views WHERE specific_id = '$html_id'");

    if($sql->num_rows > 0){
        $con->query("UPDATE html_views SET html_data = '$html_text', type = '$type' WHERE specific_id = '$html_id' ");
$msg = 'site updated : editor function : By Piki Gene 0782 954 717';
    }else{
        $con->query("INSERT INTO html_views (user_id,html_data,specific_id,type,created_at,updated_at) VALUES ('$user_id','$html_text','$html_id','$type',NOW(),NOW() )");
        $msg = 'site changed : editor function : By Piki Gene 0782 954 717';
    }

    exit(json_encode(array($msg)));
}
}else{
    exit('not authorized');
}

if(isset($_POST['get_site'])){

    $html_tags = [];

    $sql = $con->query("SELECT * FROM html_views");

    if($sql->num_rows >0 ){
      while($webgene = mysqli_fetch_assoc($sql)){
        $html_tags[] = array("user_id" => $webgene['user_id'],"type" => $webgene['type'], "html_id" => $webgene["specific_id"], "html_text" => $webgene['html_data']);
      }
    }else{
        $html_tags = [];
    }
    exit(json_encode($html_tags));

}

//exit(json_encode(array($msg)));
