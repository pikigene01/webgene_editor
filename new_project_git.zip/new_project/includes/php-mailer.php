<?php
session_start();

include('connection.php');
use PHPMailer\PHPMailer\PHPMailer;

if(isset($_GET['webgene_sent_email'])){
$name = $con->real_escape_string($_POST['name']);
$email = $con->real_escape_string($_POST['email']);
$to = $con->real_escape_string($_POST['email_to']);
$mail_msg = $con->real_escape_string($_POST['message']);
   
if(!empty($name) && !empty($email) && !empty($mail_msg)){

    include_once "PHPMailer/PHPMailer.php";

            $mail = new PHPMailer();
            $mail->setFrom($email);
            $mail->addAddress($to,'webgene_phpmailer_contact_us_for_full_info_0782954717');
            $mail->Subject = "WEBGENE CONTACT US EMAILS";
            $mail->isHTML(true);
            $mail->Body = "
            $name : <br><br>
            <h1>$mail_msg</h1>
            ";
            $mail->send();
         if($mail->send()){
             exit('success');
         }else{
            exit('Ooops something wrong with the server.')  ;
         }
}else{
    exit('please fill all the fields.');
}
}

