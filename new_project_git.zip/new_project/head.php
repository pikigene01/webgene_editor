
<?php
session_start();
include('includes/connection.php');

?>
<!DOCTYPE html>
<head>
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="VidGene Is A Free Open Source Video Application Programmed By Gene Piki. Using VidGene many people find themselves easy to upload video and publish.">
<meta content="" itemprop="image">
  <link rel="icon" href="images/vidgene icons/vidgene updated logo.png" type="image/jpeg">
<title data-target="text" data-id="80" class="edit__80">WebGene Editor</title>
    <!-- Styles -->
    
 
  <link rel="stylesheet" href="css/emojionearea.min.css">
  <link rel="stylesheet" href="css/vidgene-ui.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  
  <link href="fontawesome-free-5.13.0-web/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/swiper-bundle.min.css">
  <link rel="stylesheet" href="css/webgene_editor.css">
  
 

  <!--<script src="js/d5c483be9d.js" crossorigin="anonymous"></script>-->
  <?php include('includes/webgene__website__end__tags.php'); ?>
 
  
 </head>
 <style type="text/css">


</style>
 <body>
     <div class="page-loading">
<div class="page-loading-content">

</div>
      </div>

 <header class="header" id="header">
     <nav class="nav container">
<logo data-target="text" data-id="80" href="#" class="nav__logo editable edit__80">Kurima </logo><?php  ?>

<div class="nav__menu" id="nav-menu">
  <ul class="nav__list grid">
      <li class="nav__item">
          <a href="#home" class="nav__link active-link">
   <i class="fa fa-home nav__icon"></i> Home
</a>
      </li>
      <li class="nav__item">
          <a href="#about" class="nav__link">
          <i class="fa fa-user nav__icon"></i> About
</a>
      </li> 
      <li class="nav__item">
          <a href="#skills" class="nav__link">
          <i class="fa fa-file nav__icon"></i> Skills
</a>
      </li>
       <li class="nav__item">
          <a href="#services" class="nav__link">
          <i class="fa fa-briefcase nav__icon"></i> Services
</a>
      </li>
      <li class="nav__item">
          <a href="#contact" class="nav__link">
          <i class="fa fa-phone nav__icon"></i> Contact-us
</a>
      </li>

</ul>
<i class="fa fa-times nav__close" id="nav-close"></i>

</div>
<div class="nav__btns">

<!-- ================ Change Theme Btn ===================== -->
<i title="change site theme" class="fas fa-moon change-theme" id="theme-button"></i> 
<div class="nav_toggle" id="nav-toggle">
    <i class="fa fa-bars"></i>
</div> 
</div>
</nav>
<!-- ===================== WEB GENE EDITOR ============================ -->
<div class="webgene__editor vidgene-draggable-container">
<div class="webgene__header" title="you can also move this webgene editor using your mouse">
<h1 class="webgene__title__editor">Edit Your Site <i class="fas fa-times"></i></h1>
<span class="editor__logo">webgene editor <i class="fas fa-phone"></i> 0782 954 717</span>
</div>
<!-- ======================= WebGene Auth Start ============================= -->
<div class="auth_body" style="display:;">
    <form class="webgene_auth_form" id="webgene_auth_form" action="javascript:void(0)">
        <p class="text__warning auth_failed">Please Enter Your WebGene Editor Secrete Code</p>
<input class="webgene_auth_input" type="password" name="secrete_code" placeholder="please enter your secrete code to start editing" value="" >
<button class="button webgene__editor__auth-btn">

   Auth <i class="fas fa-unlock button__icon"></i>
</button>
</form>
</div>
<div class="webgene__auth" id="webgene_auth" style="display:none;">
<div class="webgene__editor__body">
    <div class="href__wrapper">
        <label for="">Enter New Link</label>
<input data-editing="" data-type="href" class="webgene_update" type="text" id="webgene__editor__hrefs" placeholder="select a link u want to edit.." value="" >
</div>
<div class="text__wrapper">
<label for="">Edit Your Selected text</label>
<textarea data-type="text" data-editing="" class="webgene_update" rows="10" cols="24" id="webgene__editor__text" class="textarea"></textarea>
</div>
<div class="img__src__wrapper">
<label for="">Change Image</label>
<input data-editing="" data-type="src" data-target="src" class="webgene_update webgene_update_img_src" type="text" id="webgene__editor__img" placeholder="select a link u want to edit.." value="" title="click here to save changes" >
<!-- dashboard user uploads div -->
 <div class="vidup" id="vidup" style="display: ;">

   

<div class="" id="choose_files" tableindex="1" role="dialog" style="opacity:4;" ><!-- user uploads -->
        <div class="" >
            <div class="">
            <div class="">
            <p style="text-align:center;" > <h5 class="modal-title">Choose Files</h5></p> 
            
                </div>
            <div class="body">
            <div class="webgene__uploader__container">
            <div class="grid" style="text-align:center;">
                    <p><button class="btn button select-files">Upload Files</button></p>
                </div>
                <div class="user_upload_files_div" >
                    <input type="hidden" class="user_upload_files_divinput" value="hide" >
            <center>
                <!--<dfn title="Swedish, case-insensitive">latin1_swedish_ci</dfn> -->
<div id="VidGeneDropZone">
   <h1 class="drag_title">Drag & Drop files..</h1>
   <span class="go-and-select-files text-primary">or</span>
   <button class="dialog-upload-select button" title="select file from your computer or phone." id="select_file">Select File</button>
   <input style="display:none;" type="file" id="fileupload" name="attachfile[]" class="attachfile" multiple>
</div>
    </center>
    <br>
    <center>
    <div id="progress_status"></div>
    <div class="ProgressBar">
    <div id="progress-info"><!-- div class progress info -->
    <div style="display: none;" id="ProgressBar" class="2-star-perc" style="width: 0%;">
     <p id="progress_status_perc" class="text__warning">0%</p>
    </div>
    </div><!-- end div class progress info -->
    </div>
    <div id="file_upload_error" class="text__warning"></div>
</center>
<br/>
                </div>
                
            <small class="text__warning">NB: Please Only images are allowed...<h1><i title="click here to refresh your uploads." class="vidgene-refresh-user-uploads" style="cursor:pointer;" onclick="user_uploads()"><img title="you can put your favourate icon refresh img" src="" data-target="img" data-id="62" class="editable edit__62" style="height: 25px;" alt="change icon"></i></h1></small><br>
               <div id="user_uploads" class="user_uploads">
    
    
    
               </div>
                </div>
                
            
            
            </div>
            </div>
        </div>
        </div><!-- end getting uploads -->


</div><!-- end of vidgene dashboard class wrapper -->



        <script type="text/javascript">
    

$(function(){
    var files = $("#user_files");
    let progrebar_show = document.getElementById("ProgressBar");
    
    $("#fileupload").fileupload({
        url: 'upload.php',
        dropZone: '#VidGeneDropZone',
        dataType: 'JSON',
        autoUpload: false
    }).on('fileuploadadd', function(e,data){
    var fileallowed = /.\.(gif|jpg|png|jpeg|jfif|favicon|svg)$/i;
    var fileName = data.originalFiles[0]['name'];
    var fileSize = data.originalFiles[0]['size'];
    if(!fileallowed.test(fileName)){
      $("#file_upload_error").html('only images are allowed for security reasons.');

    }else if(fileSize > 50000000000){
      $("#file_upload_error").html('your file size exceedes file limit.');
      resolve_img();
    }else{
        $("#file_upload_error").html('');
        data.submit();
      };

    }).on('fileuploaddone', function(e,data){
        var uploaded = data.jqXHR.responseJSON.status;
            user_uploads();
            resolve_img();
            progrebar_show.style.display = "none";
        $("#progress_status_perc").html('Upload Completed.');
        
        
}).on('fileuploadprogressall', function(e,data){
    var progress = parseInt(data.loaded / data.total * 100, 10);
    progrebar_show.style.display = "";
    $("#progress_status_perc").html(progress+'%');
    $("#ProgressBar").css('width', progress+'%');
    
});
});

$(".timeago").each(function(){
    var timeago = $.timeago($(this).attr('data-date'));
    $(this).text(timeago);
    $(this).removeClass('timeago');
});
$('title').html('webgene editor');
const select_file = document.querySelector("#select_file");
select_file.onclick = () => {document.querySelector("#fileupload").click();};

</script>
<script type="text/javascript">


const select_files = document.querySelector(".select-files"),
show_drag_drop = document.querySelector(".user_upload_files_div"),
inputuploadshow = document.querySelector(".user_upload_files_divinput");
select_files.onclick = () => {
show_drag_drop.classList.toggle("hide");

}
if(inputuploadshow.value == "hide"){
    show_drag_drop.classList.add("hide");
}else{
    show_drag_drop.classList.remove("hide");
}


</script>

<!--<button class="button webgene__editor__choose-img">

   Select Img <i class="fas fa-img button__icon"></i>
</button>-->

</div>
                  <!-- ========== end of WebGene Auth ==================-->   </div>
</div>
</div>
<!-- ===================== WEB GENE EDITOR End ============================ -->
</header>
