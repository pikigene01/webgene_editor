<?php
session_start();
include("includes/connection.php");
if(isset($_FILES['attachfile'])){

   
   
    $var = date_create();
    $time = date_format($var, 'Ymd');
    $foldername = time();
    $person = '1';
          $foldername = str_shuffle($foldername);
          $tokenreal = substr($foldername, 0, 4);
          $realfoldername = $time.'_WebGene_'.$tokenreal;
          mkdir('imgs/'.$realfoldername, 0777, true);
      $folder = $realfoldername;
      $file_name = $_FILES['attachfile']['name'][0];
      $files = explode('.',$file_name);
      $file_name = $files[0];
      $file_ext = $files[1];
      $target = 'imgs/'.$folder.'/'.substr(time(),0,6).'_WebGene_Upload.'.$file_ext;
      $upload_size = $_FILES['attachfile']['size'][0];
          move_uploaded_file($_FILES['attachfile']['tmp_name'][0],$target);
    $upload_type = $_FILES['attachfile']['type'][0];
    $status = array('status' => 1, 'message' => 'Your File Has Been Uploaded.');
        
    $con->query("INSERT INTO users_uploads (user_id,upload_link,upload_type,upload_folder,upload_size,created_at) VALUES ('1','$target','$upload_type','$folder','$upload_size',NOW() )");

     exit(json_encode($status));
  
}

if(isset($_POST['delete_published'])){
    $published_id = $con->real_escape_string($_POST['upload_id']);
    $folder = $con->real_escape_string($_POST['folder']);
    $con->query("DELETE FROM users_uploads WHERE upload_id = '$published_id' and user_id = '1' ");
  
    $files = scandir('imgs/'.$folder);
  foreach ($files as $file){
      if($file === '.' or $file === '..'){
          continue;
      }else{
  unlink('imgs/'.$folder . '/' . $file);
      }
  }
    if(rmdir('imgs/'.$folder)){
        exit('Post Deleted Successfully.');
    }
    
}
?>


