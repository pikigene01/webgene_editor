<?php
include('head.php');
?>
<main class="main">
<section class="home section" id="home" >
<div class="home__container container grid">
<div class="home__content grid">
<div class="home__social">
<webgeneeditorhref data-target="href" data-id="1" data-href="https://wa.me/company_phone" class="home__social__icon editable edit__1" >
<i class="fab fa-whatsapp"></i>
</webgeneeditorhref>
<webgeneeditorhref data-target="href" data-id="2" data-href="https://www.facebook.com/company_name" class="home__social__icon editable edit__2" >
<i class="fab fa-facebook"></i>
</webgeneeditorhref>
<webgeneeditorhref data-target="href" data-id="3" data-href="https://www.instagram.com/company_name" class="home__social__icon editable edit__3" >
<i class="fab fa-instagram"></i>
</webgeneeditorhref>
</div>
  <div class="home__img">
<img data-target="img" data-id="5" src="imgs/farm-1.jfif" class="hero__img editable edit__5" alt="home image hero" >
</div><!-- end home__img div -->
<div class="home__data">
<h1 data-target="text" data-id="6" class="home__title editable edit__6">WebGene Title</h1>
<p data-target="text" data-id="7" class="home__description editable edit__7">
   WebGene Description
</p>
<a data-target="href" data-id="8"  href="#contact" class="button button--flex editable edit__8">
    Contact Us <i class="fas fa-envelope button__icon"></i>
</a>
</div>

</div>
<div class="home__scroll">
<a data-target="href" data-id="9" href="#about" class="home__scroll-button button--flex editable edit__9">
    <i class="fas fa-mouse home__scroll-mouse"></i>
    <span class="home__scroll-name">Scroll Down</span>
    <i class="fas fa-arrow-down home__scroll-arrow"></i>
</a>
</div>
   </div>
</section>
<!-- ================== About Section ==================== -->
<section class="about section" id="about">
<h2 data-target="text" data-id="10" class="section__title editable edit__10">About Us</h2>
<span data-target="text" data-id="11" class="section__subtitle editable edit__11">Our Introduction</span>
<div class="about__container container grid">
  <img data-target="img" data-id="12" src="imgs/agriculture-3.jfif" alt="about us image" class="about__img editable edit__12">
  <div class="about__data">
<p data-target="text" data-id="13" class="about__description editable edit__13">
WebGene Description
</p>
<div class="about__info">
<div>
    <span data-target="text" data-id="14" class="about__info-title editable edit__14">08+</span>
     <span data-target="text" data-id="15" class="about__info-name editable edit__15">Years <br> experiance</span>
</div>
</div>
<div class="about__buttons">
<a href="javascript:void(0)" onclick="window.open('', 'popup', 'width=740,height=480,scrollbars=no, toolbar=no,status=no,resizable=yes,menubar=no,location=no,directories=no,top=10,left=10')" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.website.com%2<?php echo $link ?>" class="button button--flex">
    Share to FB <i class="fas fa-share"></i>
</a>
</div>
</div>
</div>
</section>
<section class="skills section" id="skills">
<h2 data-target="text" data-id="16" class="section__title editable edit__16">Skills</h2>
<span data-target="text" data-id="17" class="section__subtitle editable edit__17">Our Technical Level</span>

<div class="skills__container container grid">
<div>
<!-- =================== Skills 1 =================== -->
<div class="skills__content skills__close">
<div class="skills__header">
<i class="fas fa-tre skills__icon"><img data-target="img" data-id="70" src="" class="editable edit__70" src="" alt="icon"></i>

<div>
<h1 data-target="text" data-id="18" class="skills__title editable edit__18">WebGene Work 1</h1>
<span data-target="text" data-id="19" class="skills__subtitle editable edit__19"></span>
</div>
<i class="fas fa-angle-down skills__arrow"></i>
</div>
<div class="skills__list grid">
<div class="skills__data">
<div class="skills__titles">
<h3 data-target="text" data-id="20" class="skills__name editable edit__20">WebGene Work 1 Des</h3>
<span data-target="text" data-id="21" class="skills__number editable edit__21">99%</span>

</div>
<div class="skills__bar">
<span class="skills__percentage skills__1"></span>
</div>
</div><!-- end div skills data by gene -->
</div>
</div>
</div>
<!-- ==================== end skills 1 ====================== -->
<div>
<!-- =================== Skills 2 =================== -->
<div class="skills__content skills__close">
<div class="skills__header">
<i class="fas fa-fis skills__icon"><img data-target="img" data-id="69" src="" class="editable edit__69" src="" alt="icon"></i>

<div>
<h1 data-target="text" data-id="22" class="skills__title editable edit__22">WebGene Work 2</h1>
<span data-target="text" data-id="23" class="skills__subtitle editable edit__23">WebGene Work Des</span>
</div>
<i class="fas fa-angle-down skills__arrow"></i>
</div>
<div class="skills__list grid">
<div class="skills__data">
<div class="skills__titles">
<h3 class="skills__name">WebGene Work 2 More Details</h3>
<span data-target="text" data-id="24" class="skills__number editable edit__24">99%</span>

</div>
<div class="skills__bar">
<span class="skills__percentage skills__1"></span>
</div>
</div><!-- end div skills data by gene -->
</div>
</div>
</div>
 <!-- ==================== end skills 2 ====================== -->
 <div>
<!-- =================== Skills 3 =================== -->
 <div class="skills__content skills__close">
 <div class="skills__header">
<i class="fas fa-do skills__icon"><img data-target="img" data-id="68" src="" class="editable edit__68" alt="icon"></i>

<div>
<h1 data-target="text" data-id="25" class="skills__title editable edit__25">WebGene Work 3</h1>
<span data-target="text" data-id="26" class="skills__subtitle editable edit__26">WebGene Work 3 Des</span>
</div>
<i class="fas fa-angle-down skills__arrow"></i>
</div>
<div class="skills__list grid">
<div class="skills__data">
<div class="skills__titles">
<h3 data-target="text" data-id="27" class="skills__name editable edit__27">WebGene Work 3 More Details</h3>
<span data-target="text" data-id="28" class="skills__number editable edit__28">88%</span>

</div>
<div class="skills__bar">
<span class="skills__percentage skills__3"></span>
</div>
</div><!-- end div skills data by gene -->
</div>
</div>
</div>
<!-- ==================== end skills 3 ====================== -->
<!-- =================== Skills 4 =================== -->
<div class="skills__content skills__close">
 <div class="skills__header">
<i class="fas fa-do skills__icon"><img data-target="img" data-id="65" src="" class="editable edit__65" alt="icon" ></i>

<div>
<h1 data-target="text" data-id="25" class="skills__title editable edit__25">Animal Husbandry</h1>
<span data-target="text" data-id="26" class="skills__subtitle editable edit__26"></span>
</div>
<i class="fas fa-angle-down skills__arrow"></i>
</div>
<div class="skills__list grid">
<div class="skills__data">
<div class="skills__titles">
<h3 data-target="text" data-id="66" class="skills__name editable edit__66">Raising of livestock and cultivation of crops.</h3>
<span data-target="text" data-id="67" class="skills__number editable edit__67">88%</span>

</div>
<div class="skills__bar">
<span class="skills__percentage skills__3"></span>
</div>
</div><!-- end div skills data by gene -->
</div>
</div>
</div>
<!-- ==================== end skills 4 ====================== -->

</div>
</section>

<section class="portifolio section" id="services">
<h2 data-target="text" data-id="29" class="section__title editable edit__29">Our Work</h2>
<span data-target="text" data-id="30" class="section__subtitle editable edit__30">Most Recent Work</span>

<div class="portfolio__container container swiper-container">
    <div class="swiper-wrapper">
<!-- ==================== work 1 ================= -->
<div class="portfolio__content grid swiper-slide">
<img data-target="img" data-id="31" src="imgs/poultry-1.jfif" alt="" class=" portfolio__img editable edit__31">
<div class="portfolio__data">
<h3 data-target="text" data-id="32" class="portfolio__title editable edit__32">WebGene Recent Work 1</h3>
<p data-target="text" data-id="33" class="portfolio__description editable edit__33">WebGene Recent Work 1 Short Descr</p>
<a data-target="href" data-id="34" href="#" class="button button--flex button--small portfolio__button editable edit__34">
    More 
    <i class="fas fa-image button__icon"></i>
</a>
</div>
</div>
<!-- ==================== end work 1 ================= -->

<!-- ==================== work 2 ================= -->
<div class="portfolio__content grid swiper-slide">
<img data-target="img" data-id="35" src="imgs/poultry-2.jfif" alt="" class="portfolio__img editable edit__35">
<div class="portfolio__data">
<h3 data-target="text" data-id="36" class="portfolio__title editable edit__36">WebGene Recent Work 2</h3>
<p data-target="text" data-id="37" class="portfolio__description editable edit__37">WebGene Recent Work 2 Short Descr</p>
<a data-target="href" data-id="38" href="#" class="button button--flex button--small portfolio__button editable edit__38">
    More 
    <i class="fas fa-image button__icon"></i>
</a>
</div>
</div>
<!-- ==================== end work 2 ================= -->
<!-- ==================== work 3 ================= -->
<div class="portfolio__content grid swiper-slide">
<img data-target="img" data-id="39" src="imgs/cows-1.jfif" alt="" class="portfolio__img editable edit__39">
<div class="portfolio__data">
<h3 data-target="text" data-id="40" class="portfolio__title editable edit__40">WebGene Recent Work 3</h3>
<p data-target="text" data-id="41" class="portfolio__description editable edit__41">WebGene Recent Work 3 Short Descr</p>
<a data-target="href" data-id="42" href="#" class="button button--flex button--small portfolio__button editable edit__42">
    More 
    <i class="fas fa-image button__icon"></i>
</a>
</div>
</div>
<!-- ==================== end work 3 ================= -->
</div>
<div class="swiper-button-next"> 
    <i class="fas fa-arrow-right swiper-portfolio-icon"></i>
</div>
<div class="swiper-button-prev">
<i class="fas fa-arrow-left swiper-portfolio-icon"></i>
</div>
<div class="swiper-pagination"></div>

</div>
</section>

<section class="contact section" id="contact">
<h2 data-target="text" data-id="43" class="section__title editable edit__43">Contact Us</h2>
<span data-target="text" data-id="44" class="section__subtitle editable edit__44">Get in touch</span>

<div class="contact__container container grid">
    <div>
<div class="contact__information">
<i class="webgene_editor_icon contact__icon"><img data-target="img" data-id="72" src="" class="editable edit__72" src="" alt="icon"></i>
<div>
<h3 data-target="text" data-id="45" class="contact__title editable edit__45">Call Us</h3>
<span data-target="text" data-id="46" class="contact__subtitle editable edit__46">0782 954 717</span>
</div>
</div>

<div class="contact__information">
<i class="webgene_editor_email_icon contact__icon"><img data-target="img" data-id="71" src="" class="editable edit__71" src="" alt="icon"></i>
<div>
<h3 data-target="text" data-id="47" class="contact__title editable edit__47">Email</h3>
<span data-target="text" data-id="48" class="contact__subtitle editable edit__48">example@gmail.com</span>
</div>
</div>

<div class="contact__information">
<i class="webgene_editor_icon contact__icon"><img data-target="img" data-id="74" src="" class="editable edit__74" src="" alt="icon"></i>
<div>
<h3 data-target="text" data-id="49" class="contact__title editable edit__49">Location</h3>
<span data-target="text" data-id="50" class="contact__subtitle editable edit__50">Pax House Kwame street</span>
</div>
</div>
</div>
<form id="sent_email_form" action="javascript:void(0)" method="POST" class="contact__form grid">
<div class="contact__inputs grid">
 <div class="contact__content">
  <label for="" class="contact__label">Name</label>
  <input type="text" name="name" placeholder="enter your name" class="contact__input">
 </div>
 <div class="contact__content">
  <label for="" class="contact__label">Email</label>
  <input type="email" name="email" placeholder="please enter your email" class="contact__input">
 </div>
 <div class="contact__content">
  <label for="" class="contact__label"> Message</label>
  <textarea name="message"  type="text" cols="30" rows="10" class="contact__input">Type In Your Message...</textarea>
 </div>
<div>
 <button type="submit" id="sent_email_form_btn" name="sent_email" class="button button--flex">
Send Message <i class="fas fa-rocket button__icon"></i>
</button>
</div>
</div>
</form>


</div>

</section>
</main>

<footer class="footer">
<div class="footer__bg">
<div class="footer__container container grid">
<div>
<h1 data-target="text" data-id="51" class="footer__title editable edit__51">Company Name</h1>
<span data-target="text" data-id="52" class="footer__subtitle editable edit__52">Company more info</span>
</div>
<ul class="footer__links">

<li>
<a href="#contact" class="footer__link ">Contact Us</a>
</li>
<li>
<a href="#about" class="footer__link">About</a>
</li>
<li>
<a href="#services" class="footer__link">Services</a>
</li>
</ul>
<div class="footer__socials">
<a data-target="href" data-id="54" href="https://www.wa.me/phone" target="_blank" class="footer__social editable edit__54">
<i class="fab fa-whatsapp"></i>
</a>
<a data-target="href" data-id="55" href="https://www.facebook.com/company-name" target="_blank" class="footer__social editable edit__55">
<i class="fab fa-facebook"></i> 
</a>
<a data-target="href" data-id="56" href="https://www.instagram.com/company-name" target="_blank" class="footer__social editable edit__56">
<i class="fab fa-instagram"></i> 
</a>
</div>
</div>
<p class="footer__copy"><span class="site__developer__gene-piki">Site Designed By Gene. 0782 954 717</span> &#169; <span data-target="text" data-id="53" class="editable edit__53">Companyname.</span> All Rights Reserved.... </p>
</div>
</footer>

<a href="#" class="scrollup" id="scroll-up">
<i class="fas fa-arrow-up scrollup__icon"></i>
</a>

 <?php include('includes/webgene__website__end__tags.php'); ?>
<script type="text/javascript">
const navMenu = document.getElementById('nav-menu'),
navToggle = document.getElementById('nav-toggle'),
navClose = document.getElementById('nav-close');

if(navToggle){
    navToggle.addEventListener('click', () => {
        navMenu.classList.add('show-menu');
        navToggle.classList.add('hide');
    })
}
if(navClose){
    navClose.addEventListener('click', () => {
        navMenu.classList.remove('show-menu');
        navToggle.classList.remove('hide');
    })
}
const navLink = document.querySelectorAll('.nav__link');

function linkAction(){
    navToggle.classList.remove('hide');
    navMenu.classList.remove('show-menu');
}
navLink.forEach(n => n.addEventListener('click', linkAction));

let skillsContent = document.querySelectorAll('.skills__content'),
skillsHeader = document.querySelectorAll('.skills__header');

function toggleSkills(){
    
    for(let i = 0; i < skillsContent.length; i++){
        
        skillsContent[i].onclick = () => {
            for(let j=0;j < skillsContent.length; j++){
                      if(skillsContent[j].classList.contains("skills__open")){
                        skillsContent[j].classList.remove('skills__open');
                }else{
                    
                }
            } skillsContent[i].classList.add('skills__open');
        }
        
    }
    
    
}
skillsContent.forEach((el) => {
      el.onclick = () => {
        toggleSkills();
        
      }  });

 let swiper = new Swiper(".swiper-container", {
        cssMode: true,
        loop: true, 
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        pagination: {
   el: '.swiper-pagination',
   clickable: true
        },
        mousewheel: true,
        keyboard: true,
       
      });

      function scrollHeader(){
          const nav = document.getElementById('header');
          if(this.scrollY >= 80) nav.classList.add('scroll-header'); else nav.classList.remove('scroll-header');
      }
      window.addEventListener('scroll', scrollHeader);
      const sections = document.querySelectorAll('section[id]')

function scrollActive(){
    const scrollY = window.pageYOffset

    sections.forEach(current =>{
        const sectionHeight = current.offsetHeight
        const sectionTop = current.offsetTop - 50;
        sectionId = current.getAttribute('id')

        if(scrollY > sectionTop && scrollY <= sectionTop + sectionHeight){
            document.querySelector('.nav__menu a[href*=' + sectionId + ']').classList.add('active-link')
        }else{
            document.querySelector('.nav__menu a[href*=' + sectionId + ']').classList.remove('active-link')
        }
    })
}
window.addEventListener('scroll', scrollActive)
      /*function scrollActive(){
          const scrollY = widow.pageYoffset;
          let sections = document.querySelectorAll('section');
          sections.forEach(current => {
              const sectionHeight = current.offsetHeight;
              const sectionTop = current.offsetTop - 50;
              sectionId = current.getAttribute('id');

              if(scroY > sectionTop && scrollY <= sectionTop + sectionHeight){
                  document.querySelector('.nav__menu a[href*=' + sectionId + ']').classList.add('active-link');

              }esle{
                document.querySelector('.nav__menu a[href*=' + sectionId + ']').classList.remove('active-link');

              }
          })
      }
      window.addEventListener('scroll', scrollActive);


     
*/
const themeButton = document.getElementById('theme-button')
const darkTheme = 'dark-theme'
const iconTheme = 'fa-sun'

// Previously selected topic (if user selected)
const selectedTheme = localStorage.getItem('selected-theme')
const selectedIcon = localStorage.getItem('selected-icon')

// We obtain the current theme that the interface has by validating the dark-theme class
const getCurrentTheme = () => document.body.classList.contains(darkTheme) ? 'dark' : 'light'
const getCurrentIcon = () => themeButton.classList.contains(iconTheme) ? 'fa-moon' : 'fa-sun'

// We validate if the user previously chose a topic
if (selectedTheme) {
  // If the validation is fulfilled, we ask what the issue was to know if we activated or deactivated the dark
  document.body.classList[selectedTheme === 'dark' ? 'add' : 'remove'](darkTheme)
  themeButton.classList[selectedIcon === 'fa-moon' ? 'add' : 'remove'](iconTheme)
}

// Activate / deactivate the theme manually with the button
themeButton.addEventListener('click', () => {
    // Add or remove the dark / icon theme
    document.body.classList.toggle(darkTheme)
    themeButton.classList.toggle(iconTheme)
    // We save the theme and the current icon that the user chose
    localStorage.setItem('selected-theme', getCurrentTheme())
    localStorage.setItem('selected-icon', getCurrentIcon())
})

/*==================== SCROLL REVEAL ANIMATION ====================*/
const sr = ScrollReveal({
    origin: 'top',
    distance: '30px',
    duration: 2000,
    reset: false
});

sr.reveal(`.home__data, .home__img,
            .about__data, .about__img,
            .services__content, .menu__content,
            .app__data, .app__img,
            .contact__data, .contact__button,
            .footer__content`, {
    interval: 200
})
      function scrollUp(){
          const scrollUp = document.getElementById('scroll-up');
          const scrollY = window.pageYOffset;

          if(scrollY >= 560) scrollUp.classList.add('show-scroll'); else scrollUp.classList.remove('show-scroll');
      }
      window.addEventListener('scroll', scrollUp);

      /* ============================ webgene editor js ====================== */
      const editors = document.querySelectorAll('.editable'),
      webgene_editor_text = document.querySelector('#webgene__editor__text'),
      webgene_editor_href = document.querySelector('#webgene__editor__hrefs'),
      webgene_editor_img = document.querySelector('#webgene__editor__img'),
      webgene_update = document.querySelectorAll('.webgene_update'),
      ahref_edit = document.querySelectorAll('webgeneeditorhref');
      ahref_edit.forEach((hrefget) => {
        hrefget.ondblclick = () => {
            
            let target = hrefget.dataset.target,
              id = hrefget.dataset.id;
              $('.webgene__editor').show();
            var href = hrefget.getAttribute('data-href');
            
        $('.href__wrapper').show();
        $('.img__src__wrapper').hide();
        $('.text__wrapper').hide();
        webgene_editor_href.value = href;
        webgene_editor_href.dataset.editing = id;
        }
      })
      
      editors.forEach((editor) => {
        
          editor.ondblclick = () => {
       
              $('.webgene__editor').show();
              let target = editor.dataset.target,
              id = editor.dataset.id;
      if(target === 'text'){
          var text = editor.innerText;
          webgene_editor_text.value = text;
          $('.text__wrapper').show();
          $('.href__wrapper').hide();
        $('.img__src__wrapper').hide();
          webgene_editor_text.dataset.editing = id;
      }else if(target === 'href'){
        var href = editor.getAttribute('data-href');
        $('.href__wrapper').show();
        $('.img__src__wrapper').hide();
        $('.text__wrapper').hide();
        webgene_editor_href.value = href;
        webgene_editor_href.dataset.editing = id;
        
      }else{
        var src = editor.getAttribute('src');
        
        webgene_editor_img.value = src;
        
        $('.img__src__wrapper').show();
        $('.href__wrapper').hide();
        $('.text__wrapper').hide();
        webgene_editor_img.dataset.editing = id;
      }
          }
      });
      webgene_update.forEach((update_query) => {
        update_query.onkeyup = () => {
            
            let id_editing = update_query.dataset.editing,
            value = update_query.value;
            let type = update_query.dataset.type;
            
            $.ajax({
                url: 'includes/change_site.php',
                type: 'POST',
                dataType: 'JSON',
                data: {change_site:1,type:type,html_tag_id: id_editing, html_text: value }, beforeSend:function(){
                    document.body.classList.add('processing');
                    $('.page-loading').show();
                }, success:function(data){
                    document.body.classList.remove('processing');
                    $('.page-loading').hide();
                }
            });
        const editable_text = document.querySelector('.edit__'+id_editing);
        $('.edit__'+id_editing).html(value);
        
        
            
    }
        update_query.ondblclick = () => {
            
        let id_editing = update_query.dataset.editing,
        value = update_query.value;
        weggene_editor_sent(id_editing,value);
    const editable_text = document.querySelector('.edit__'+id_editing);
   
    if(update_query.dataset.target === 'src'){
       if(editable_text.hasAttribute('src')){
          
               let value = update_query.value;
               
          
               editable_text.setAttribute('src', value);

        }
    }
    
        
}


      });
      function weggene_editor_sent(id_editing,value){
          let type = 'src';
$.ajax({
                url: 'includes/change_site.php',
                type: 'POST',
                dataType: 'JSON',
                data: {change_site:1,type:type,html_tag_id: id_editing, html_text: value }, beforeSend:function(){
                    document.body.classList.add('processing');
                    $('.page-loading').show();
                }, success:function(data){
                    document.body.classList.remove('processing');
                    $('.page-loading').hide();
                }
            });
        };
      const hide_webgene_edit = document.querySelector('.webgene__title__editor i'),
      auth_up_btn_submit = document.querySelector('.webgene__editor__auth-btn'),
      webgene_auth_form = document.querySelector('#webgene_auth_form'),
      sign_up_form_text_danger = document.querySelector('.auth_failed'),
      sent_email_form = document.querySelector('#sent_email_form'),
      sent_email_form_btn = document.querySelector('#sent_email_form_btn');

     /* sent_email_form.onsubmit = (e) => {
            e.preventDafault();
        }*/
        sent_email_form_btn.onclick = () => {
     
     let xhr = new XMLHttpRequest();
     xhr.open("POST", "includes/php-mailer.php?webgene_sent_email=1", true);
     xhr.onload = () => {
          if(xhr.readyState === XMLHttpRequest.DONE){
              if(xhr.status === 200){
                  let data = xhr.response;
                  if(data == 'success'){
                    alert('sent')
                     
                  }else{
                    alert(data)
                  }
              }
          }
 
     }
     let formdata = new FormData(sent_email_form);
     xhr.send(sent_email_form);
 }
 

      auth_up_btn_submit.onclick = () => {
     
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "includes/webgene_auth.php", true);
    xhr.onload = () => {
         if(xhr.readyState === XMLHttpRequest.DONE){
             if(xhr.status === 200){
                 let data = xhr.response;
                 if(data == 'success'){
                     $('.auth_body').hide();
                    $('#webgene_auth').show();
                 }else{
                   
                 }
             }
         }

    }
    let formdata = new FormData(webgene_auth_form);
    xhr.send(formdata);
}

      hide_webgene_edit.onclick = () => {

        $('.webgene__editor').hide(); 
        $('.href__wrapper').hide();
        $('.text__wrapper').hide();
        $('.img__src__wrapper').hide();
      };

      /* ============================= WebGene Editor Select Img ========================================== */

      const all__uploaded__imgs = document.querySelectorAll('.user_upload_img');

      all__uploaded__imgs.forEach((imgs) => {
          imgs.onclick = () => {
            
              
              resolve_img();
          } 
      });
      
      function resolve_img(){
          
          let webgene_update_img_src = document.querySelector('.webgene_update_img_src');
         
      let img = document.querySelectorAll('.user_upload_img');
              for(let i=0;i < img.length; i++){img[i].onclick = function() {
                  for(let j=0;j < img.length; j++){
                      if(img[j].classList.contains("active")){
                        img[j].classList.remove('active');
                }}img[i].classList.add('active');
                let src = img[i].getAttribute('src');
               webgene_update_img_src.value = src;
               $('.webgene_update_img_src').dblclick();
            }}
            };
            user_uploads();function user_uploads(){$.ajax({url: 'includes/users_uploads.php',method: 'GET',data: {user_uploads: 1}, success:function(data){$("#user_uploads").fadeIn();$("#user_uploads").html(data);resolve_img();}});};
function delete_upload(upload_id,folder){if(confirm('Are Sure You Want To Delete This File.')){$.ajax({url: 'upload.php',method: 'POST',data: {delete_published:1,upload_id:upload_id,folder:folder}, success:function(data){user_uploads();resolve_img();}});};};

           function weggene_editor_get_html(){
            $.ajax({
                url: 'includes/change_site.php',
                type: 'POST',
                dataType: 'JSON',
                data: {get_site:1 }, beforeSend:function(){
                    document.body.classList.add('processing');
                    $('.page-loading').show();
                }, success:function(data){
                    
                    for(var i =0; i < data.length; i++){
                        
                        $('.edit__'+data[i].html_id).each(function(){
                            if(data[i].type === 'text'){
                            $(this).html(data[i].html_text);
                            }else if(data[i].type === 'src'){
                                $(this).attr('src',data[i].html_text);
                            }else if(data[i].type === 'href'){
                                $(this).attr('data-href',data[i].html_text);  
                            }
                            setInterval(function(){
                                $('.page-loading').hide();
                            }, 5000);
                            document.body.classList.remove('processing');
                        })
                    }
                   
                }
            });
           };

document.addEventListener("DOMContentLoaded", ()=> {
    
    weggene_editor_get_html();
    resolve_img();
    
});
const vidgene_get_draggable = document.querySelectorAll('.vidgene-draggable-container');
let vidgene_is_resizing = false; 

vidgene_get_draggable.forEach(draggable => {
   draggable.addEventListener('mousedown', mousedown);
   

   function mousedown(e){
       window.addEventListener('mousemove', mousemove);
       window.addEventListener('mouseup', mouseup);
       let prevX = e.clientX;
       let prevY = e.clientY;



       function mousemove(e){
           if(!vidgene_is_resizing){
           let newX = prevX - e.clientX;
           let newY = prevY - e.clientY;

const rect = draggable.getBoundingClientRect();

    draggable.style.left = rect.left - newX + "px";

    draggable.style.top = rect.top - newY + "px";


 
draggable.style.cursor = "move";

prevX = e.clientX;
prevY = e.clientY;

           };
       };
       function mouseup(){
       window.removeEventListener('mousemove', mousemove);
       window.removeEventListener('mouseup', mouseup);
    };
   };
});
</script>
</body>
</html>